import numpy as np
import Fonctions


class Dense:
    def __init__(self, inputShape, outputShape, activationFunction, activationDerivate):
        self.inputShape = inputShape #la géométrie des entrées
        self.outputShape = outputShape #la géométrie des sorties
        self.activationFunction = activationFunction #la fonction d'activation utilisée dans cette couche
        self.activationDerivate =  activationDerivate #la dérivée associée à la fonction d'activation

        self.aggregations = np.zeros(outputShape) #les sommes des entrées pondérées par les poids, plus les biais       
        self.outputs = np.zeros(outputShape) #la sortie de la couche

        self.bias =  np.zeros(outputShape) #les biais associés à chaque neurone de la couche
        
        # Choix de l'initialisation des poids en fonction de la fonction d'activation
        if activationFunction == Fonctions.relu:
            # Initialisation He pour ReLU
            std = np.sqrt(2.0 / inputShape[0])
        elif activationFunction == Fonctions.tanh or activationFunction == Fonctions.sigmoid:
            # Initialisation Xavier pour tanh
            std = np.sqrt(1.0 / inputShape[0])
        else:
            # Initialisation par défaut
            std = 1.0 / np.sqrt(inputShape[0])

        #Les poids sont stockés dans un tableau de M lignes par N colonnes, M le nombre d'entrées et N étant le nombre de neurones de la couche    
        self.weights = np.random.randn(inputShape[0], outputShape[0]) * std

        #Les erreurs calculées lors de la rétropropagation
        self.inputErrors = np.zeros(inputShape)
        self.deltas = np.zeros(outputShape)
        
    def compute(self, inputs):
        #TODO : calculer la sortie de la couche en prenant en compte les entrées, les poids, les biais et la fonction d'activation
        return np.zeros_like(self.outputShape)

    def computeError(self, outputErrors):
        #TODO : calculer le gradient des poids, des biais et l'erreur d'entrée
        pass
                
    def correction(self, learningRate):
        #TODO: mettre à jour les poids et les biais, puis remettre à zéro les gradient
        pass
    
    def __str__(self): #pour l'affiche de la structure du réseau
        return f"Couche full-connectée à {self.outputShape[0]} neurones : input={self.inputShape}, output={self.outputShape}\n"
    
    def clone(self): #copie complète de la couche, pour la sauvegarde lors de l'apprentissage
        copie = Dense(self.inputShape, self.outputShape, self.activationFunction, self.activationDerivate)
        copie.bias = self.bias.copy()
        copie.weights = self.weights.copy()
        return copie
    
    def getNbParams(self): #nombre de poids et de biais contenus dans la couche
        return self.outputShape[0] + self.outputShape[0]*self.inputShape[0]