import numpy as np
import random
from Dense import *
from Fonctions import *
from Metrics import *

class NeuralNetwork:
    def __init__(self, inputShape):
        self.inputShape = inputShape
        self.layers = []

    def clone(self):
        nn = NeuralNetwork(self.inputShape)
        for layer in self.layers:
            nn.layers.append(layer.clone())
        return nn

    def addLayer(self, size, activationFunctionStr):
        activationFunction = relu
        d_activationFunction = d_relu
        match activationFunctionStr:
            case "logistic":
                activationFunction = sigmoid
                d_activationFunction = d_sigmoid
            case "relu":
                activationFunction = relu
                d_activationFunction = d_relu
            case "elu":
                activationFunction = elu
                d_activationFunction = d_elu
            case "identity":
                activationFunction = identite
                d_activationFunction = d_identite
            case "tanh":
                activationFunction = tanh
                d_activationFunction = d_tanh
            case _:
                activationFunction = sigmoid
                d_activationFunction = d_sigmoid
        inputShape = self.inputShape if len(self.layers)==0 else self.layers[-1].outputShape
        self.layers.append(Dense(inputShape, (size,), activationFunction, d_activationFunction))
    
    def compute(self, inputs):
        #TODO : calculer la sortie du réseau de neurones en fonction des entrées
        return np.zeros(10)

    def predict(self, inputs):
        #TODO : appeler compute, et renvoyer la classe obtenant le plus grand score
        return 0
 
    def fit(self, X, y, epochs, learningRate):
        best = None
        bestAccuracy = -1
        order = [i for i in range(len(y))] #l'ordre de passage des instances dans la boucle d'apprentissage, à chaque époque
        for e in range(epochs):
            pass

        return best #on renvoie le meilleur réseau généré (du point de vue de la précision)

    def __str__(self):
        res = ""
        for layer in self.layers:
            res+=layer.__str__()
        return res
    
    def getNbParams(self):
        res = 0
        for layer in self.layers:
            res+=layer.getNbParams()
        return res