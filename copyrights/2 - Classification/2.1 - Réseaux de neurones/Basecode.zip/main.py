from sklearn import model_selection
import numpy as np
from Experts.Code.NN.Basecode.Utils_old import *
from NeuralNetwork import *
import sys

'''
Charge le fichier passé en paramètre, et met en forme les données
Procède également à la séparation train/test
'''
def chargementDataset(filename):
    data = np.loadtxt(filename)
    X = data[:,0:-1]
    y = data[:,-1]
    X = (X - np.min(X))/(np.max(X)- np.min(X))
    y = y.astype(int)

    X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, train_size=0.7, test_size=0.3)
    y_train = to_catogorical(y_train)
    y_test = to_catogorical(y_test)
    nbFeatures = len(X[0]) if len(X.shape)==2 else len(X[0])*len(X[1])
    nbClasses = len(np.unique(y)) 

    return X, y, X_train, y_train, X_test, y_test, nbFeatures, nbClasses



if len(sys.argv)!=2:
    print(f"Usage : python {sys.argv[0]} pathToFile")
    sys.exit(0)

X, y, X_train, y_train, X_test, y_test, nbFeatures, nbClasses = chargementDataset(sys.argv[1])
print(f"Details : nbInstances = {len(y)}, nbFeatures = {nbFeatures}, nbClasses = {nbClasses}")


nn = load_nn("model.txt")
print(nn)
print(f"Nombre de paramètres : {nn.getNbParams()}")

#TODO : à décommenter lors de l'implémentation de la procédure d'apprentissage
#nn = nn.fit(X_train, y_train, 100, 0.01)
print(f"train={accuracy(nn, X_train,y_train)}, test={accuracy(nn, X_test,y_test)}")
