import numpy as np

#Renvoie la précision d'un réseau de neurones
def accuracy(model, X, y):
    score = 0
    for i in range(len(X)):
        score+=y[i][model.predict(X[i])]
    return score/len(X)

#Renvoie la mse d'un réseau de neurones
def mse(model, X, y):
    score = 0
    #TODO : pour chaque instance, calculer la somme des carrés des différences entre le vecteur attendu et le vecteur renvoyé par compute
    return score/len(X*len(y[0]))