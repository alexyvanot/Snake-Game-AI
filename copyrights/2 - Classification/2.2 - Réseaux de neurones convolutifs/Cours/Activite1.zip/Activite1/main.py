import numpy as np 
import sys
from skimage import io
import matplotlib.pyplot as plt

if __name__=="__main__":
    if len(sys.argv)!=2:
        print(f"Usage : python main.py imagePath")
        sys.exit(0)
    
    src = np.array(io.imread(sys.argv[1]), dtype=np.float32)
    H, W = src.shape[0], src.shape[1]
    
    src = np.pad(src, pad_width=1, mode='constant', constant_values=0)
    plt.imshow(src, cmap="gray")
    plt.title("Image originale")
    plt.show()

    dest = np.zeros((H,W), dtype=np.float32)
    print(src.shape)

    noyau = np.array([
            [0, -1, 0],
            [-1, 5, -1],
            [0, -1, 0]
    ])

    dest = np.zeros((H,W))
    for l in range(H):
        for c in range(W):
            dest[l][c] = np.sum(src[l:l+3, c:c+3]*noyau)

    dest = np.clip(dest, 0, 255)
    plt.imshow(dest, cmap="gray")
    plt.title("Image après convolution (filtre sharpen)")
    plt.show()