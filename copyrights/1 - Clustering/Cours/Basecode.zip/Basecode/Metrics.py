import numpy as np


def computeInertia(centroids, labels, X):
    return 0

def DBI(centroids, labels, X):
    return 0

