from PIL import Image
import numpy as np
import cv2
hauteur, largeur = 1140, 942
lignes, colonnes = 20, 20
vignetteHauteur, vignetteLargeur = hauteur//lignes, largeur//colonnes

candidats = np.array(range(0, 25))
np.random.shuffle(candidats)
K = 12
selectionnes = candidats[:K]
print(selectionnes)
filename = "olivettifaces.gif"

image = np.array(Image.open(filename))
counter = 0
arr = np.array(range(1,401))
np.random.shuffle(arr)
patches = []
for k in selectionnes:
    nbFaces = np.random.randint(5, 11)
    vignettes = np.random.choice(np.array(range(10)), nbFaces)
    for i in vignettes:
        ligne = k//2
        colonne = i + (0 if k%2==0 else 10)
        patches.append(image[ligne*vignetteHauteur+1:(ligne+1)*vignetteHauteur-1, colonne*vignetteLargeur+1:(colonne+1)*vignetteLargeur-1])

patches = np.array(patches)
np.random.shuffle(patches)
for patch in patches:
    cv2.imwrite(
        f"{counter}.png",
        patch
    )
    counter += 1

